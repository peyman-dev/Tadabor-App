import React from 'react'
import LoadingScreen from '../components/common/loading-screen'

const AuthLoading = () => {
    return <LoadingScreen />
}

export default AuthLoading