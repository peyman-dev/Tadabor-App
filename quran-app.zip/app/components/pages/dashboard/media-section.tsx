"use client"

import React from 'react'
import VideoStream from './Video/VideoStream'
import { useHolyStore } from '@/app/core/stores/holy.store';
import AudioPlayer from './Audio/AudioPlayer';
import { generateMediaSrc } from '@/app/actions';
const MediaSection = () => {
    const { data } = useHolyStore()

    console.log(data?.audio)

    return (
        <div className='md:w-1/2'>
            <VideoStream />
            <AudioPlayer src={generateMediaSrc(String(data?.audio?.idmedia))} />
        </div>
    )
}

export default MediaSection