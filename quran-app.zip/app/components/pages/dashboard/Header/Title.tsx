import React from 'react'
// className='md:visible md:block hidden invisible'

const HeaderTitle = () => {
    return (
        <div >
            <p className='text-[#412B6C] text-xs md:text-[20px]'>
                {/* تـــدبــــــــــــر */}
                تدبر
            </p>
        </div>
    )
}

export default HeaderTitle